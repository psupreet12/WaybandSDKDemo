//
//  WayBandSDK.h
//  WayBandSDK
//
//  Created by Unizen on 23/02/22.
//

#import <Foundation/Foundation.h>

//! Project version number for WayBandSDK.
FOUNDATION_EXPORT double WayBandSDKVersionNumber;

//! Project version string for WayBandSDK.
FOUNDATION_EXPORT const unsigned char WayBandSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WayBandSDK/PublicHeader.h>


